local _ = require("gettext")
return {
    name = "MyUpload",
    fullname = _("MyUploads),
    description = _([[This plugin starts / stops MyUpload server.]]),
}
